--Lua Testing Script
CursorX = GetScreenCursorX()
CursorY = GetScreenCursorY()

Print("CursorX: ")
Print(CursorX)

Print("\nCursorY: ")
Print(CursorY)