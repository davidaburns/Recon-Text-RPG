--Lua Menu Testing
DisplayMenu("Test1", "Test2", "Test3")