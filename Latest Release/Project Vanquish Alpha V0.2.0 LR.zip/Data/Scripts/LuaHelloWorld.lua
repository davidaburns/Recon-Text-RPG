--Lua Hello World
Print("Hello World of Lua!")