--TestNpc Script
DialogText("Hello my name is, TestNpc.\n")
DialogText("This dialog is coming from the TestNpc.lua script.\n")
DialogText("You can find my script in the Script/NPC/ folder.\n")