--Dialog Text for TestNpc2
DialogText("This is text for TestNpc2.\n");
DialogText("So far all us, npcs, can do is just draw text to the screen.\n")
DialogText("But we can also draw color text which is pretty cool! :)\n")

DialogText("/#0Color$\n")
DialogText("/#1Color$\n")
DialogText("/#4Color$\n")

